package cucumberTest;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "C:\\Users\\JagadishBR\\eclipse-workspace\\CucumberSDETProjects\\src\\Features",
    glue = {"stepDefinitions"},
    tags = {"@SuiteCRMActivities"},
    plugin = {"pretty", "html: target/cucumber-reports/Project3-reports"},
    monochrome = true,
    strict = true
)

public class ActivitiesRunner {
    //empty
}
